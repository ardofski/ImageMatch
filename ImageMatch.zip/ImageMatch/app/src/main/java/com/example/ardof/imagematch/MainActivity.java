package com.example.ardof.imagematch;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import static java.lang.Thread.sleep;



public class MainActivity extends AppCompatActivity {


    int[] dogImages = {1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8};
    boolean[] isOpened = new boolean[16];
    boolean isSecond = false;
    boolean showAvaible = true;
    String firstTag, secondTag,imageName;
    int resID,firstIndex,secondIndex;
    ImageView image1, image2;
    final Handler handler = new Handler();


    public void showImage(int index,ImageView img){
        imageName = "dog" + index;
        resID = getResources().getIdentifier( imageName ,"drawable",this.getPackageName());
        img.setImageResource(resID);
        isOpened[ Integer.parseInt(String.valueOf( (img.getTag() ) ) ) - 1 ] = true;
    }

    // Implementing Fisher–Yates shuffle

    static void shuffleArray(int[] ar)
    {
        for (int i = ar.length - 1; i > 0; i--)
        {
            int index = (int)((Math.random())*(ar.length)) ;
            // Simple swap
            int a = ar[index];
            ar[index] = ar[i];
            ar[i] = a;
        }
    }

    public void show(View view){
        if( ( ! isOpened[ ( Integer.parseInt( String.valueOf( ((ImageView)view).getTag() ) )   - 1 ) ] ) && showAvaible ){
            if( !isSecond ){
                image1 = (ImageView) view;

                //getTag
                firstTag = String.valueOf( image1.getTag() );

                //getİndex
                firstIndex =  dogImages[ Integer.parseInt( firstTag )   - 1 ];

                System.out.println( "firstindex is: " + firstIndex );

                //show image
                showImage( firstIndex , image1 );

                //next element is second one
                isSecond = true;

            }
            else{

                showAvaible = false;

                image2 = (ImageView) view;

                //get Tag

                secondTag = String.valueOf( image2.getTag() );

                //getIndex
                secondIndex =  dogImages[ Integer.parseInt( secondTag )   - 1 ];

                System.out.println( "second index is: " + secondIndex );

                //Show image
                showImage( secondIndex, image2 );

                //if it equals with first tag, do nothing

                //check if the game is finished
                boolean isGameFinished = true;
                for( int i = 0 ; i < 16 ; i++){
                    if( isOpened[i] == false)
                        isGameFinished = false;
                }
                if( isGameFinished ){
                    LinearLayout finishedLayout = (LinearLayout)findViewById(R.id.end);
                    finishedLayout.setVisibility( View.VISIBLE );

                }

                //if they don't match close both



                if( firstIndex != secondIndex ){

                    handler.postDelayed(new Runnable() {
                        public void run() {

                            //close first image
                            image1.setImageResource(R.drawable.unknown);
                            isOpened[ Integer.parseInt( firstTag ) - 1 ] = false;

                            //close second image
                            image2.setImageResource(R.drawable.unknown);
                            isOpened[ Integer.parseInt( secondTag ) - 1 ] = false;

                        }
                    }, 700);


                }

                isSecond = false;

                handler.postDelayed(new Runnable() {
                    public void run() {
                        showAvaible = true;
                    }
            }, 800);

            }

        }




    }


    public void playAgain(View view){
        GridLayout gridLayout = (GridLayout) findViewById(R.id.gridLayout);
        for(int i = 0 ; i < gridLayout.getChildCount() ; i++ ){
            ((ImageView)gridLayout.getChildAt( i )).setImageResource( R.drawable.unknown );
            isOpened[i] = false;
        }
        isSecond = false;
        LinearLayout finishedLayout = (LinearLayout)findViewById(R.id.end);
        finishedLayout.setVisibility( View.INVISIBLE );
        shuffleArray( dogImages );
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        shuffleArray( dogImages );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
